


var bad_acct_number = 2,
    bad_email = 'demo@travelbyroad.net';


var domain = 'dev.rdbhost.com',
    acct_number = 14,
    demo_email = 'jsdemos@travelbyroad.net';